﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Security.Principal;
using System.Web.Security;

namespace SecureServiceLibrary
{
  public class SecureService : ISecureService
  {
    public string SayHello()
    {
      return string.Format("Hello {0}",
        System.Threading.Thread.CurrentPrincipal.Identity.Name);
    }

    public decimal ReportSales()
    {
      IIdentity currentUser =
        ServiceSecurityContext.Current.PrimaryIdentity;
      if (Roles.IsUserInRole(currentUser.Name, "Member"))
      {
        return 10000M;
      }
      else
      {
        return -1;
      }
    }
  }
}
