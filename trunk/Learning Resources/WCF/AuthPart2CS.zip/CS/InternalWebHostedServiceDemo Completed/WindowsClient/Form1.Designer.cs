﻿namespace WindowsClient
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.reportSalesButton = new System.Windows.Forms.Button();
      this.sayHelloButton = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.nameTextBox = new System.Windows.Forms.TextBox();
      this.passwordTextBox = new System.Windows.Forms.TextBox();
      this.logInButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // reportSalesButton
      // 
      this.reportSalesButton.Location = new System.Drawing.Point(215, 148);
      this.reportSalesButton.Name = "reportSalesButton";
      this.reportSalesButton.Size = new System.Drawing.Size(125, 39);
      this.reportSalesButton.TabIndex = 4;
      this.reportSalesButton.Text = "Report sales";
      this.reportSalesButton.UseVisualStyleBackColor = true;
      this.reportSalesButton.Click += new System.EventHandler(this.reportSalesButton_Click);
      // 
      // sayHelloButton
      // 
      this.sayHelloButton.Location = new System.Drawing.Point(48, 148);
      this.sayHelloButton.Name = "sayHelloButton";
      this.sayHelloButton.Size = new System.Drawing.Size(125, 39);
      this.sayHelloButton.TabIndex = 3;
      this.sayHelloButton.Text = "Say hello";
      this.sayHelloButton.UseVisualStyleBackColor = true;
      this.sayHelloButton.Click += new System.EventHandler(this.sayHelloButton_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(45, 38);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(49, 17);
      this.label1.TabIndex = 3;
      this.label1.Text = "Name:";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(45, 76);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(73, 17);
      this.label2.TabIndex = 4;
      this.label2.Text = "Password:";
      // 
      // nameTextBox
      // 
      this.nameTextBox.Location = new System.Drawing.Point(134, 35);
      this.nameTextBox.Name = "nameTextBox";
      this.nameTextBox.Size = new System.Drawing.Size(100, 23);
      this.nameTextBox.TabIndex = 0;
      // 
      // passwordTextBox
      // 
      this.passwordTextBox.Location = new System.Drawing.Point(134, 73);
      this.passwordTextBox.Name = "passwordTextBox";
      this.passwordTextBox.PasswordChar = '*';
      this.passwordTextBox.Size = new System.Drawing.Size(100, 23);
      this.passwordTextBox.TabIndex = 1;
      // 
      // logInButton
      // 
      this.logInButton.Location = new System.Drawing.Point(265, 27);
      this.logInButton.Name = "logInButton";
      this.logInButton.Size = new System.Drawing.Size(75, 39);
      this.logInButton.TabIndex = 2;
      this.logInButton.Text = "Log in";
      this.logInButton.UseVisualStyleBackColor = true;
      this.logInButton.Click += new System.EventHandler(this.logInButton_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(384, 215);
      this.Controls.Add(this.logInButton);
      this.Controls.Add(this.passwordTextBox);
      this.Controls.Add(this.nameTextBox);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.sayHelloButton);
      this.Controls.Add(this.reportSalesButton);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Authentication and Authorization Demo";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    internal System.Windows.Forms.Button reportSalesButton;
    internal System.Windows.Forms.Button sayHelloButton;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox nameTextBox;
    private System.Windows.Forms.TextBox passwordTextBox;
    internal System.Windows.Forms.Button logInButton;
  }
}

