//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BurnCD.rc
//
#define IDCANCEL                        2
#define IDD_BURNCD_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_BURN_FILE_LIST              1000
#define IDC_ADD_FILES_BUTTON            1001
#define IDC_ADD_FOLDER_BUTTON           1002
#define IDC_REMOVE_FILES_BUTTON         1003
#define IDC_DEVICE_COMBO                1004
#define IDC_BURN_BUTTON                 1011
#define IDC_PROGRESS_TEXT               1012
#define IDC_PROGRESS                    1013
#define IDC_BUFFER_TEXT                 1014
#define IDC_BUFFER_PROG                 1015
#define IDC_ESTIMATED_TIME              1016
#define IDC_TIME_LEFT                   1017
#define IDC_SUPPORTED_MEDIA_TYPES       1019
#define IDC_MEDIA_TYPE_COMBO            1020
#define IDC_CAPACITY                    1021
#define IDC_MAX_TEXT                    1022
#define IDC_VOLUME                      1023
#define IDC_CLOSE_MEDIA_CHK             1024
#define IDC_EJECT_WHEN_FINISHED         1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
