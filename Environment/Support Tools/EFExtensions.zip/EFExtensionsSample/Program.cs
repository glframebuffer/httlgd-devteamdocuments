﻿//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Objects;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Microsoft.Data.Extensions;
using MiniNWModel;

namespace EFExtensionsSample
{
    public class Program
    {
        private static readonly string separator = new string('-', 40);
        private readonly TextWriter _log;

        public Program(TextWriter log)
        {
            _log = log ?? Console.Out;
        }

        #region Main()
        private static void Main(string[] args)
        {
            string connectionString = args.FirstOrDefault();
            Program program = new Program(null);
            program.RunTests(connectionString);
        }

        public void RunTests(string connectionString)
        {
            // run all invoke all methods taking a MiniNW context in this class
            IEnumerable<MethodInfo> sampleMethods = typeof(Program).GetMethods(BindingFlags.Instance | BindingFlags.Public).Where(m =>
                m.GetParameters().Length == 1 &&
                m.GetParameters().Single().ParameterType == typeof(MiniNWEntities));

            foreach (MethodInfo sampleMethod in sampleMethods.OrderBy(m => m.Name))
            {
                _log.WriteLine();
                _log.WriteLine(separator);
                _log.WriteLine(sampleMethod.Name);
                _log.WriteLine(separator);

                using (MiniNWEntities context = connectionString == null ? new MiniNWEntities() : new MiniNWEntities(connectionString))
                {
                    try
                    {
                        sampleMethod.Invoke(this, new object[] { context });
                    }
                    catch (TargetInvocationException e)
                    {
                        throw e.InnerException;
                    }
                }
            }
        }
        #endregion

        #region Illustrating first class relationships
        public void UpdateCategory(MiniNWEntities context)
        {
            Category food = context.Categories.Where(c => c.Name == "Food").First();
            Product beer = context.Products.Where(p => p.Name == "Beer").First();

            _log.WriteLine("Before changing the category:");
            DisplayStateManager(context);

            beer.Category = food;

            _log.WriteLine("After changing the category:");
            DisplayStateManager(context);
        }
        #endregion

        #region EntitySet<T> samples (also see Model_partial.cs)
        public void EntitySet_Queries(MiniNWEntities context)
        {
            // EntitySet<T> derives from ObjectQuery<T> and can therefore
            // be used with LINQ to Entities queries and Entity-SQL builder
            // methods.
            var query = from c in context.Categories
                        where c.Name.StartsWith("B")
                        select c;
            DisplayResults(query);

            query = context.Categories.Where("it.Name like 'B%'");
            DisplayResults(query);
        }

        public void EntitySet_StateManagement(MiniNWEntities context)
        {
            // Entities can be managed with respect to the EntitySet. This
            // provides slightly simpler patterns because the entity set name
            // does not need to specified.
            context.Categories.DeleteObject(context.Categories.First());
            context.Categories.Attach(new Category { CategoryID = 3, Name = "Condiments" });
            context.Categories.AddObject(new Category { CategoryID = 4 });
            DisplayStateManager(context);
        }
        #endregion

        #region Materializer<T> sample (also see Model_partial.cs)
        public void Materializer_RenameColumns(MiniNWEntities context)
        {
            Category category = context.GetCategory(1);
            _log.WriteLine(category);
        }

        public void Materializer_PolymorphicResults(MiniNWEntities context)
        {
            context.GetProductsByCategory(2).ToList();
            DisplayStateManager(context);
        }

        public void Materializer_MultipleResultSets(MiniNWEntities context)
        {
            // The following method uses two result sets to retrieve a category
            // and its related products. The product results are polymorphic.
            Category category = context.GetCategoryAndRelatedProducts(2);
            DisplayStateManager(context);
        }

        public void Materializer_MultipleResultSetsMerge(MiniNWEntities context)
        {
            // The following method uses two result sets to retrieve all categories
            // and all products. Products and categories are associated using 
            // the product CategoryReference.
            var results = context.GetAllCategoriesAndAllProducts();
            DisplayStateManager(context);
        }

        public void Materializer_AdhocQuery(MiniNWEntities context)
        {
            // Project column names corresponding to property names for an object
            // and use default materialization pattern to produce results.
            var results = context
                .CreateStoreCommand("select cid as CategoryID, [name] as Name from Categories")
                .Materialize<Category>();
            DisplayResults(results);
        }

        public void Materializer_MultipleEntitiesPerRow(MiniNWEntities context)
        {
            var result = context.GetProductAndCategory(1);
            _log.WriteLine(result + " -> " + result.Category);
        }
        #endregion

        #region Misc utilities
        public void Misc_ExpandInvocationExpressions(MiniNWEntities context)
        {
            // Combine two predicates using Invocation, and then apply to entity query.
            Expression<Func<Product, bool>> predicate1 = p => p.ProductID == 1;
            Expression<Func<Product, bool>> predicate2 = p => p.ProductID == 2;
            Expression<Func<Product, bool>> disjunction = Expression.Lambda<Func<Product, bool>>(
                Expression.Or(predicate1.Body, Expression.Invoke(predicate2, predicate1.Parameters.Cast<Expression>())),
                predicate1.Parameters);
            var query = context.Products.Where(disjunction);

            // Rewrite query to remove InvocationExpression
            query = query.ExpandInvocations();

            DisplayResults(query);
        }

        public void Misc_IsGenericAssignableFrom(MiniNWEntities context)
        {
            // When using reflection code, it is sometimes convenient to ask
            // if a type of assignable to a generic type definition (e.g., I want
            // to know if a type is assignable to IEnumerable<T> but I don't have
            // a concrete type.
            Type[] genericArguments;
            if (typeof(IEnumerable<>).IsGenericAssignableFrom(typeof(ObjectSet<Product>), out genericArguments))
            {
                _log.WriteLine("EntitySet<Product> implements IEnumerable<" + genericArguments.Single().Name + ">");
            }
        }
        #endregion

        #region ObjectQuery<T> extensions
        public void ObjectQuery_LinqToTraceString(MiniNWEntities context)
        {
            var query = from p in context.Products
                        where p is DiscontinuedProduct
                        select new { p.ProductID, (p as DiscontinuedProduct).DiscontinuedDate };
            DisplayResults(query);
            context.Connection.Open();

            // Using the ToTraceString utility method, we can call ObjectQuery.ToTraceString
            // on an instance that is statically typed as an IQueryable<anonymous type>.
            _log.WriteLine(query.ToTraceString());
        }

        public void ObjectQuery_LinqMergeOption(MiniNWEntities context)
        {
            var query = from c in context.Categories
                        where c.Products.Any()
                        select c;

            query = query.SetMergeOption(MergeOption.OverwriteChanges);
            DisplayResults(query);
        }

        public void ObjectQuery_Include(MiniNWEntities context)
        {
            var query = from c in context.Categories
                        where c.Products.Any(p => p is DiscontinuedProduct)
                        select c;

            query.Include("Products").ToList();
            DisplayStateManager(context);
        }
        #endregion

        #region EntityReference
        public void EntityReference_SetKey(MiniNWEntities context)
        {
            Product product = new Product
            {
                ProductID = 10,
                Name = "New Beverage",
            };
            int categoryID = (from c in context.Categories
                              where c.Name == "Beverage"
                              select c.CategoryID).First();

            // Note that the product must be attached to the context before
            // we can set the key. Otherwise, the necessary metadata is not
            // available.
            context.Products.AddObject(product);
            product.CategoryReference.SetKey(categoryID);
            DisplayStateManager(context);
        }
        #endregion

        #region Helpers
        public void DisplayResults<T>(IEnumerable<T> results)
        {
            _log.WriteLine("Results:");
            _log.WriteLine(separator);
            foreach (T element in results)
            {
                _log.WriteLine("    " + element);
            }
            _log.WriteLine();
        }

        public void DisplayStateManager(ObjectContext context)
        {
            _log.WriteLine("ObjectStateManager contents:");
            _log.WriteLine(separator);
            foreach (ObjectStateEntry stateEntry in context.ObjectStateManager.GetObjectStateEntries(~EntityState.Detached))
            {
                _log.WriteLine("  " + stateEntry.EntitySet + "(" + stateEntry.State + ")");
                if (!stateEntry.IsRelationship)
                {
                    if (null != stateEntry.Entity)
                    {
                        _log.WriteLine("    " + stateEntry.Entity);
                    }
                    else
                    {
                        _log.WriteLine("    Stub entity " + DescribeEntityKey(stateEntry.EntityKey));
                    }
                }
                else
                {
                    DbDataRecord record = stateEntry.State == EntityState.Deleted ?
                        stateEntry.OriginalValues :
                        stateEntry.CurrentValues;
                    _log.WriteLine("    <" + DescribeEntityKey((EntityKey)record[0]) + ", " + DescribeEntityKey((EntityKey)record[1]) + ">");
                }
            }
            _log.WriteLine();
        }

        private static string DescribeEntityKey(EntityKey entityKey)
        {
            if (entityKey.IsTemporary)
            {
                return "temporary";
            }
            else
            {
                return string.Join(",", entityKey.EntityKeyValues
                    .Select(pair => string.Format(CultureInfo.InvariantCulture, "{0}={1}", pair.Key, pair.Value))
                    .ToArray());
            }
        }
        #endregion
    }
}
