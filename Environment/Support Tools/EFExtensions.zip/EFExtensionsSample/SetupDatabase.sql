-- Copyright (c) Microsoft Corporation.  All rights reserved.

/*
use master
go
drop database MiniNW
go
create database MiniNW
go
*/
use MiniNW
go

-- create tables
create table Categories(cid int primary key, [name] nvarchar(max));
create table Products(pid int primary key, [name] nvarchar(max), discontinued_date datetime null, cid int not null references Categories(cid));
go

-- create stored procedures
create proc GetCategory
    @cid int
as
begin
    select *
    from Categories
    where @cid = cid
end
go

create proc GetProductsByCategory
    @cid int
as
begin
    select *
    from Products
    where @cid = cid
end
go

create proc GetCategoryAndProducts
    @cid int
as
begin
    exec GetCategory @cid;
    exec GetProductsByCategory @cid;
end
go

create proc GetProductAndCategory
    @pid int
as
begin
    select p.pid, p.[name] as pname, p.discontinued_date, c.cid, c.[name] as cname
    from Products as p join Categories as c on p.cid = c.cid
    where p.pid = @pid    
end
go

create proc GetAllCategoriesAndAllProducts
as
begin
	select *
    from Categories;
    select *
    from Products as p;
end
go

-- insert data
insert into Categories(cid, [name])
select 1, 'Beverage'
union all
select 2, 'Food';

insert into Products(pid, [name], discontinued_date, cid)
select 1, 'Beer', null, 1
union all
select 2, 'Jam', null, 2
union all
select 3, 'Water', null, 1
union all
select 4, 'Toast', '2007-12-15', 2l;

select * from Categories
select * from Products
exec GetProductAndCategory 1