﻿//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Objects;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using Microsoft.Data.Extensions;

namespace MiniNWModel
{
    public partial class MiniNWEntities : ObjectContext
    {
        #region Materializer<T>
        // Note use of static instances. Materializer<T> is thread-safe to prevent
        // multiple compilations of optimized delegates.

        // Materializer performing column renames.
        private static readonly Materializer<Category> s_categoryMaterializer = new Materializer<Category>(r =>
            new Category
            {
                CategoryID = r.Field<int>("cid"),
                Name = r.Field<string>("name"),
            });

        // Materializer returning different types based on a condition.
        private static readonly Materializer<Product> s_productMaterializer = new Materializer<Product>(r =>
            r.Field<DateTime?>("discontinued_date").HasValue ?
            (Product)new DiscontinuedProduct
            {
                ProductID = r.Field<int>("pid"),
                Name = r.Field<string>("name"),
                DiscontinuedDate = r.Field<DateTime>("discontinued_date"),
                CategoryReference =
                {
                    EntityKey = new EntityKey("MiniNWEntities.Categories", new[] { new EntityKeyMember("CategoryID", r.Field<int>("cid")) }),
                },
            } :
            new Product
            {
                ProductID = r.Field<int>("pid"),
                Name = r.Field<string>("name"),
                CategoryReference =
                {
                    EntityKey = new EntityKey("MiniNWEntities.Categories", new[] { new EntityKeyMember("CategoryID", r.Field<int>("cid")) }),
                },
            });

        // Materializer returning two entities from a single row.
        private static readonly Materializer<KeyValuePair<Product, Category>> s_productAndCategoryMaterializer = new Materializer<KeyValuePair<Product, Category>>(r =>
            new KeyValuePair<Product, Category>(
                new Product { ProductID = r.Field<int>("pid"), Name = r.Field<string>("pname") },
                new Category { CategoryID = r.Field<int>("cid"), Name = r.Field<string>("cname") }));

        /// <summary>
        /// Gets a category with the requested ID using a stored procedure.
        /// </summary>
        /// <param name="categoryID">ID of category to retrieve.</param>
        /// <returns>Category with given ID or null if none is found.</returns>
        public Category GetCategory(int categoryID)
        {
            // The CreateStoreCommand utility method simplified creation
            DbCommand command = this.CreateStoreCommand("GetCategory", CommandType.StoredProcedure, new SqlParameter("cid", categoryID));
            Category category = s_categoryMaterializer
                .Materialize(command)   // Returns typed results given a DB command.
                .SingleOrDefault();     // We expect at most a single match for this stored procedure.
            return this.Categories.FindOrAttach(category); // We bind the result to an entity set so that it can be tracked.
        }

        /// <summary>
        /// Gets all products in the given category.
        /// </summary>
        /// <param name="categoryID">ID of category for products.</param>
        /// <returns>Products.</returns>
        public IEnumerable<Product> GetProductsByCategory(int categoryID)
        {
            DbCommand command = this.CreateStoreCommand("GetProductsByCategory", CommandType.StoredProcedure, new SqlParameter("cid", categoryID));
            return s_productMaterializer
                .Materialize(command)
                .Bind(this);
        }

        /// <summary>
        /// Gets a category with the requested ID and populates related products using
        /// a single stored procedure call. The procedure returns multiple result sets:
        /// the first set returns the category and the second set returns related products.
        /// </summary>
        /// <param name="categoryID">Category ID.</param>
        /// <returns>Category with given ID or null if none is found.</returns>
        public Category GetCategoryAndRelatedProducts(int categoryID)
        {
            DbCommand command = this.CreateStoreCommand("GetCategoryAndProducts", CommandType.StoredProcedure, new SqlParameter("cid", categoryID));
            Category category;

            using (command.Connection.CreateConnectionScope())
            using (DbDataReader reader = command.ExecuteReader())
            {
                // first result set includes the category
                category = s_categoryMaterializer
                    .Materialize(reader)
                    .Bind(this.Categories)
                    .SingleOrDefault();

                // second result set includes the related products
                if (null != category && reader.NextResult())
                {
                    category.Products.Attach(s_productMaterializer
                        .Materialize(reader)
                        .Bind(this.Products));
                }
            }

            return category;
        }

        /// <summary>
        /// Gets all categories and all products in two separate result sets and associates them.
        /// </summary>
        /// <returns>All categories.</returns>
        public IEnumerable<Category> GetAllCategoriesAndAllProducts()
        {
            DbCommand command = this.CreateStoreCommand("GetAllCategoriesAndAllProducts", CommandType.StoredProcedure);
            List<Category> categories = new List<Category>();

            using (command.Connection.CreateConnectionScope())
            using (DbDataReader reader = command.ExecuteReader())
            {
                categories = s_categoryMaterializer
                    .Materialize(reader)
                    .Bind(this.Categories)
                    .ToList();

                // Now read products. Associate them with the category using entity reference.
                if (reader.NextResult())
                {
                    s_productMaterializer
                        .Materialize(reader)
                        .Bind(this.Products)
                        .ToList();
                }
            }

            return categories;
        }

        /// <summary>
        /// Gets a product and its related category.
        /// </summary>
        /// <param name="pid">Product id</param>
        /// <returns>Product</returns>
        public Product GetProductAndCategory(int pid)
        {
            DbCommand command = this.CreateStoreCommand("GetProductAndCategory", CommandType.StoredProcedure, new SqlParameter("pid", pid));

            var productAndCategory = s_productAndCategoryMaterializer.Materialize(command).SingleOrDefault();

            Product product = this.Products.FindOrAttach(productAndCategory.Key);
            if (null != product)
            {
                product.CategoryReference.Attach(this.Categories.FindOrAttach(productAndCategory.Value));
            }

            return product;
        }
        #endregion
    }

    #region Entity class ToString implementations
    public partial class Category
    {
        public override string ToString()
        {
            return String.Format(CultureInfo.InvariantCulture, "Category {0}: {1}", this.CategoryID, this.Name);
        }
    }

    public partial class Product
    {
        public override string ToString()
        {
            return String.Format(CultureInfo.InvariantCulture, "Product {0}: {1}", this.ProductID, this.Name);
        }
    }

    public partial class DiscontinuedProduct
    {
        public override string ToString()
        {
            return String.Format(CultureInfo.InvariantCulture, "DiscontinuedProduct {0}: {1}, {2}", this.ProductID, this.Name, this.DiscontinuedDate);
        }
    }
    #endregion
}
